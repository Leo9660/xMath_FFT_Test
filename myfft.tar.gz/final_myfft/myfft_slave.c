#include <math.h>
#include "myfft.h"
#include "slave.h"
#include "dma.h"
#include "simd.h"
#include "myfft_cossin.h"

#define MAX_N 2048
#define TRANSPOSE_SIZE 32
#define P_NUM 64

__thread_local __attribute__((aligned (128))) double* input, *w;

double get_sin(int n)
{
	if (n < 512) return mysin[n];
	return mycos[n - 512];
}

double get_cos(int n)
{
	if (n < 512) return mycos[n];
	return -mysin[n - 512];
}

double my_sin2_(int n, int base, double x0, double xx0)
{
	double delta = n * x0 - base * xx0;
	double r1 = mysin[base], r2 = mycos[base];
	double delta2 = delta * delta;
	return r1 + r2 * delta - r1 * delta2 / 2 - r2 * delta2 * delta / 6;
}

double my_cos2_(int n, int base, double x0, double xx0)
{
	double delta = n * x0 - base * xx0;
	double r1 = mysin[base], r2 = mycos[base];
	double delta2 = delta * delta;
	return r2 - r1 * delta - r2 * delta2 / 2 + r1 * delta2 * delta / 6;
}

double my_sin2(int n, int base, double x0, double xx0, int N)
{
	int n4 = N / 4;
	if (n < n4) return my_sin2_(n, base, x0, xx0);
	if (n < 2 * n4) return my_cos2_(n - n4, base - 512, x0, xx0);
	if (n < 3 * n4) return -my_sin2_(n - 2 * n4, base - 1024, x0, xx0);
	return -my_cos2_(n - 3 * n4, base - 1536, x0, xx0);
}

double my_cos2(int n, int base, double x0, double xx0, int N)
{
	int n4 = N / 4;
	if (n < n4) return my_cos2_(n, base, x0, xx0);
	if (n < 2 * n4) return -my_sin2_(n - n4, base - 512, x0, xx0);
	if (n < 3 * n4) return -my_cos2_(n - 2 * n4, base - 1024, x0, xx0);
	return my_sin2_(n - 3 * n4, base - 1536, x0, xx0);
}

void myF_v4(int n, int s, double *x);

void bit_reverse(int n, double* x)
{
	int i, j, k;
	for (i = 0, j = 1; j < n - 1; j++)
	{
		for (k = n >> 1; k > (i ^= k); k >>= 1);
		if (i < j)
		{
			double t = RE(x, i);
			RE(x, i) = RE(x, j);
			RE(x, j) = t;
			t = IM(x, i);
			IM(x, i) = IM(x, j);
			IM(x, j) = t;
		}
	}
}

void myfft_slave(double **args)
{
	int id = athread_get_id(-1);
	int dimension = *((int*)args[3]);
	int size = *((int*)args[2]);
	int N = size * size;
	int offset = id * size;
	int length = size * 2 * sizeof(double);
	unsigned long t1, t2;
	int start, pos;

	w = (__thread_local double*)ldm_malloc(length / 2);

	if (dimension == 1)
	{
		input = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length);
		
		int status = 0;
		volatile unsigned long reply = 0;
		dma_desc __da__=0;
		dma_set_op(&__da__, DMA_GET);
		dma_set_mode(&__da__, PE_MODE);
		dma_set_size(&__da__, length);
		dma_set_reply(&__da__, &reply);
		dma(__da__, args[0] + pos, input);
		dma_wait(&reply, 1);
	
		myF_v4(size, size, input);
		bit_reverse(size, input);

		reply = 0;
		dma_set_op(&__da__, DMA_PUT);
		dma(__da__, args[1] + pos, input);
		dma_wait(&reply, 1);
		ldm_free(input, length);
	}
	
	if (dimension == 2)
	{
		input = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length);
		volatile unsigned long reply = 0;
		dma_desc __da__=0;
		dma_set_mode(&__da__, PE_MODE);
		dma_set_size(&__da__, length);
		dma_set_reply(&__da__, &reply);
		int i;

		for (start = offset; start < N; start += 64*size)
		{
			reply = 0;
			pos = start * 2;
	
			dma_set_op(&__da__, DMA_GET);
			dma(__da__, args[0] + pos, input);
			dma_wait(&reply, 1);

			myF_v4(size, size, input);
			bit_reverse(size, input);

			reply = 0;
			dma_set_op(&__da__, DMA_PUT);
			dma(__da__, args[1] + pos, input);
			dma_wait(&reply, 1);
		}
		ldm_free(input, length);
	}
	ldm_free(w, length / 2);
}	

void myfft_transpose(double **args)
{
	int id = athread_get_id(-1);
	int size = *((int*)args[2]);
	int multiple = *((int*)args[3]);
	int n = TRANSPOSE_SIZE;
	int N = size * size;
	int bnpr = size / n;
	int bn = bnpr * bnpr;
	int i, j, k;
	int length = n * n * sizeof(double) * 2;
	int len_one = n * sizeof(double) * 2;

	input = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length);

	volatile unsigned long reply = 0;
	dma_desc __da__ = 0;
	dma_set_mode(&__da__, PE_MODE);
	dma_set_size(&__da__, len_one);
	dma_set_reply(&__da__, &reply);
	if (multiple) w = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length);
	for (i = id; i < bn; i += 64)
	{
		int row = i / bnpr;
		int col = i % bnpr;
		int pos1 = (row * n * size + col * n) * 2;
		int pos2 = (col * n * size + row * n) * 2;
		if (!multiple)
		{
			dma_set_op(&__da__, DMA_GET);
			reply = 0;
			for (j = 0; j < n; j++)
			{
				int offset = j * n  * 2;
				int Offset = j * size * 2;
				dma(__da__, args[0] + pos1 + Offset, input + offset);
			}
			dma_wait(&reply, n);
			
			for (j = 0; j < n; j++)
				for (k = j; k < n; k++)
				{
					int p1 = j * n + k;
					int p2 = k * n + j;
					double t = RE(input, p1);
					RE(input, p1) = RE(input, p2);
					RE(input, p2) = t;
					t = IM(input, p1);
					IM(input, p1) = IM(input, p2);
					IM(input, p2) = t;
				}
		}
		else
		{
			dma_set_op(&__da__, DMA_GET);
			reply = 0;

			for (j = 0; j < n; j++)
			{
				int offset = j * n  * 2;
				int Offset = j * size * 2;
				dma(__da__, args[0] + pos1 + Offset, input + offset);
			}
			
			double x0 = 2 * M_PI / N;
			double xx0 = 2 * M_PI / 2048;
			double scale = 1.0 * 2048 / N;
			int r_off = row * n, c_off = col * n;
			for (j = 0; j < n; j++)
			{
				int jj = r_off + j;
				for (k = 0; k < n; k++)
				{
					int kk = c_off + k;
					int n0 = jj * kk;
					int base = (int)(n0 * scale + 0.5);
					RE(w, j * n + k) = my_cos2(n0, base, x0, xx0, N);
					IM(w, j * n + k) = -my_sin2(n0, base, x0, xx0, N);
				}
			}

			dma_wait(&reply, n);
			
			for (j = 0; j < n; j++)
				for (k = j; k < n; k++)
				{
					int p1 = j * n + k;
					int p2 = k * n + j;
					double tr1 = RE(input, p1),
					tr2 = RE(input, p2),
					ti1 = IM(input, p1),
					ti2 = IM(input, p2),
					wr1 = RE(w, p1),
					wi1 = IM(w, p1),
					wr2 = RE(w, p2),
					wi2 = IM(w, p2);

					RE(input, p2) = tr1 * wr1 - ti1 * wi1;
					IM(input, p2) = ti1 * wr1 + tr1 * wi1;
					RE(input, p1) = tr2 * wr2 - ti2 * wi2;
					IM(input, p1) = ti2 * wr2 + tr2 * wi2;
				}
		}

		reply = 0;
		dma_set_op(&__da__, DMA_PUT);
		for (j = 0; j < n; j++)
		{
			int offset = j * n * 2;
			int Offset = j * size * 2;
			dma(__da__, args[1] + pos2 + Offset, input + offset);
		}
		dma_wait(&reply, n);
	}
	
	ldm_free(input, length);
	ldm_free(w, length);
}

void myF_v4(int n, int s, double *x)
{
	if (s == 2)
	{
		int m = s / 2;
		int stride = 2048 / s;
		int i, j = 0;

		int hs = s / 2;
		int sj, ns = n / s, thetaD = 0;
		for (sj = 0; sj < hs; sj++)
		{
			const double wp_re = get_cos(thetaD),
			wp_im = -sqrt(1 - wp_re * wp_re);
			thetaD += stride;
			int p1 = sj, p2 = sj + hs;
			while (p2 < n)
			{
				const double a_re = RE(x, p1),
				a_im = IM(x, p1),
				b_re = RE(x, p2),
				b_im = IM(x, p2);
				
				RE(x, p1) = a_re + b_re;
				IM(x, p1) = a_im + b_im;
				
				const double t_re = a_re - b_re,
				t_im = a_im - b_im;
				
				RE(x, p2) = t_re * wp_re - t_im * wp_im;
				IM(x, p2) = t_re * wp_im + t_im * wp_re;
				
				p1 += s;
				p2 += s;
			}
		}
	}
	else if (s >= 4)
	{
		int m = s / 4,
		m2 = s / 2,
		m3 = m + m2;
		int stride = 2048 / s;
		int sj;
		int off21 = m * stride;
		int theta1 = 0, theta2, theta3;
		for (sj = 0; sj < m; sj++)
		{
			int p1 = sj, p2 = p1 + m,
			p3 = p1 + m2, p4 = p1 + m3;
			theta2 = off21 + theta1;
			theta3 = theta1 + theta1;
			double wr1, wr2, wr3, wi1, wi2, wi3, wr4, wi4, wr5, wi5;
			wr1 = get_cos(theta1);
			wi1 = -sqrt(1 - wr1 * wr1);
			wr2 = wi1;
			wi2 = -wr1;
			wr3 = wr1 * wr1 - wi1 * wi1;
			wi3 = wr1 * wi1 * 2;

			while (p1 < n)
			{
				double r1 = RE(x, p1),
				i1 = IM(x, p1),
				r2 = RE(x, p2),
				i2 = IM(x, p2),
				r3 = RE(x, p3),
				i3 = IM(x, p3),
				r4 = RE(x, p4),
				i4 = IM(x, p4);
				
 				double tr, ti;				
				tr = r1 - r3;
				ti = i1 - i3;
				
				r1 = r1 + r3;
				i1 = i1 + i3;
				r3 = tr * wr1 - ti * wi1;
				i3 = tr * wi1 + ti * wr1;

				tr = r2 - r4;
				ti = i2 - i4;
				
				r2 = r2 + r4;
				i2 = i2 + i4;
				r4 = tr * wr2 - ti * wi2;
				i4 = tr * wi2 + ti * wr2;

				tr = r1 - r2;
				ti = i1 - i2;

				r1 = r1 + r2;
				i1 = i1 + i2;
				r2 = tr * wr3 - ti * wi3;
				i2 = tr * wi3 + ti * wr3;

				tr = r3 - r4;
				ti = i3 - i4;

				r3 = r3 + r4;
				i3 = i3 + i4;
				r4 = tr * wr3 - ti * wi3;
				i4 = tr * wi3 + ti * wr3;
				
				RE(x, p1) = r1;
				IM(x, p1) = i1;
				RE(x, p2) = r2;
				IM(x, p2) = i2;
				RE(x, p3) = r3;
				IM(x, p3) = i3;
				RE(x, p4) = r4;
				IM(x, p4) = i4;

				p1 += s;
				p2 += s;
				p3 += s;
				p4 += s;
			}
			theta1 += stride;
		}
		myF_v4(n, m, x);
	}
}

void myfft_process(double **args)
{
	int id = athread_get_id(-1);
	int n = *((int*)args[2]);
	int d = *((int*)args[3]);
	int m = n / 2;
	int stride = m / 64;
	if (stride > MAX_N / 2) stride = MAX_N / 2;
	int s_2 = stride / 2;
	int l1 = stride * sizeof(double) * 2;
	int l2 = l1 * 2;
	input = (__thread_local double*)ldm_malloc(l2);

	if (d == 0)
	{
		int start;
		for (start = id * stride; start < m; start += 64 * stride)
		{
			volatile unsigned long reply = 0;
			dma_desc __da__ = 0;
			dma_set_op(&__da__, DMA_GET);
			dma_set_mode(&__da__, PE_MODE);
			dma_set_size(&__da__, l1);
			dma_set_reply(&__da__, &reply);
			dma(__da__, args[0] + start * 2, input);
			dma(__da__, args[0] + (start + m) * 2, input + stride * 2);
			dma_wait(&reply, 2);
			
			int i;
			double theta0 = 2 * M_PI / n;
			int factor = n / 2048;
			int base = (start + factor / 2) / factor;
			int count = (start + factor / 2) % factor;
			double x0 = 2 * M_PI / n, xx0 = 2 * M_PI / 2048;
			for (i = 0; i < stride; i++)
			{
				double wr = my_cos2(i + start, base, x0, xx0, n),
				wi = -sqrt(1 - wr * wr),
				ar = RE(input, i),
				ai = IM(input, i),
				br = RE(input, i + stride),
				bi = IM(input, i + stride);
				RE(input, i) = ar + br;
				IM(input, i) = ai + bi;
				double tr = ar - br,
				ti = ai - bi;
				RE(input, i + stride) = tr * wr - ti * wi;
				IM(input, i + stride) = tr * wi + ti * wr;
				
				count++;
				if (count == factor)
				{
					count = 0;
					base++;
				}
			}
	
			reply = 0;
			dma_set_op(&__da__, DMA_PUT);
			dma(__da__, args[1] + start * 2, input);
			dma(__da__, args[1] + (start + m) * 2, input + stride * 2);
			dma_wait(&reply, 2);
		}
		ldm_free(input, l2);
	}
	else
	{
		int i;
		w = (__thread_local double*)ldm_malloc(l1);
		int start;
		for (start = id * stride; start < m; start += 64 * stride)
		{
			volatile unsigned long reply = 0;
			dma_desc __da__ = 0;
			dma_set_op(&__da__, DMA_GET);
			dma_set_mode(&__da__, PE_MODE);
			dma_set_size(&__da__, l1);
			dma_set_reply(&__da__, &reply);
			dma(__da__, args[0] + start * 2, input);
			dma(__da__, args[0] + (start + m) * 2, input + stride * 2);
			dma_wait(&reply, 2);
			
			for (i = 0; i < stride / 2; i++)
			{
				RE(w, 2 * i) = RE(input, i);
				IM(w, 2 * i) = IM(input, i);
				RE(w, 2 * i + 1) = RE(input, i + stride);
				IM(w, 2 * i + 1) = IM(input, i + stride);
			}
			reply = 0;
			dma_set_op(&__da__, DMA_PUT);
			dma(__da__, args[1] + start * 4, w);

			for (i = s_2; i < stride; i++)
			{
				RE(input, 2 * i - stride) = RE(input, i);
				IM(input, 2 * i - stride) = IM(input, i);
				RE(input, 2 * i - stride + 1) = RE(input, i + stride);
				IM(input, 2 * i - stride + 1) = IM(input, i + stride);
			}
			dma(__da__, args[1] + (start * 2 + stride) * 2, input);
			dma_wait(&reply, 2);
		}
		ldm_free(input, l2);
		ldm_free(w, l1);
	}
}

