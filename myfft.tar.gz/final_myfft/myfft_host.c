#include "athread.h"
#include "simd.h"
#include "myfft.h"
#include <math.h>
#include <stdio.h>

extern SLAVE_FUN(myfft_slave)();
extern SLAVE_FUN(myfft_transpose)();
extern SLAVE_FUN(myfft_process)();

void sixstep_fft(int log_N, double *in, double *out)
{
	const int N = 1 << log_N;
	const int n = 1 << (log_N / 2);
	int m = 0;
	
	double* args_t1[4] = {in, out, (double*)&n, (double*)&m};
	//transpose-1
	athread_spawn(myfft_transpose, args_t1);
	athread_join();

	//FFT-1
	int d = 2;
	double* args[4] = {out, in, (double*)&n, (double*)&d};	
	athread_spawn(myfft_slave, args);
	athread_join();

	//transpose and multiply twiddle factor
	m = 1;
	athread_spawn(myfft_transpose, args_t1);
	athread_join();

	//FFT-2
	args[0] = out;
	args[1] = in;
	athread_spawn(myfft_slave, args);
	athread_join();
	
	//transpose-2
	m = 0;
	athread_spawn(myfft_transpose, args_t1);
	athread_join();
}

void eightstep_fft(int log_N, double *in, double *out)
{
	int N = 1 << log_N;
	int m = N / 2;
	int d = 0;
	double* args[4] = {in, out, (double*)&N, (double*)&d};
	athread_spawn(myfft_process, args);
	athread_join();

	sixstep_fft(log_N - 1, out, in);
	sixstep_fft(log_N - 1, out + 2 * m, in + 2 * m);

	d = 1;
	athread_spawn(myfft_process, args);
	athread_join();
}

myfft_complex myfft_malloc(int n)
{
	return (double*)malloc(n * 2 * sizeof(double));
}

int myfft_hzd(double *in, double *out, int N)
{
	int i;
	int log_N = 0;
	for (i = N; i > 1; i >>= 1) log_N++;
	int n = 1 << (log_N / 2);

	if (N != 1 << log_N)
	{
		printf("Invalid input array size! (N should be a power of 2)\n");
		return -1;
	}
	if (N < 2 || N > 8388608)
	{
		printf("Invalid array size! (2 <= N <= 8M)");
		return -1;
	}

	unsigned long t1, t2;

	athread_init();

	if (log_N > 11)
	{
		if (!(log_N & 1)) sixstep_fft(log_N, in, out);
		else eightstep_fft(log_N, in, out);
	}
	else
	{
		int d = 1;
		double* args[4] = {in, out, (double*)&N, (double*)&d};
		athread_spawn(myfft_slave, args);
		athread_join();
	}
	
	return 0;
}
