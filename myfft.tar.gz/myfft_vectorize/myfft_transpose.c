#include <math.h>
#include "myfft.h"
#include "slave.h"
#include "dma.h"
#include "simd.h"

void myfft_transpose(double args**)
{
	int id = athread_get_id(-1);
	int size = *((int*)args[2]);
	int n = TRANSPOSE_SIZE;
	int bnpr = size / n;
	int bn = bnpr * bnpr;
	int i, j, k;
	int length = n * n * sizeof(double) * 2;
	int len_one = n * sizeof(double) * 2;

	input = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length);	
	
	volatile unsigned long reply = 0;
	dma_desc __da__ = 0;
	dma_set_mode(&__da__, PE_MODE);
	dma_set_size(&__da__, len_one);
	dma_set_reply(&__da__, &reply);
	for (i = id; i < bn; i += 64)
	{
		int row = i / bnpr;
		int col = i % bnpr;
		int pos1 = (row * n * size + col * n) * 2;
		int pos2 = (col * n * size + row * n) * 2;
		dma_set_op(&__da__, DMA_GET);
		reply = 0;
		for (j = 0; j < n; j++)
		{
			int offset = j * n * sizeof(double) * 2;
			int Offset = j * size * sizeof(double) * 2;
			dma(__da__, args[0] + pos1 + Offset, input + offset);
		}
		dma_wait(&reply, n);
		
		for (j = 0; j < n; j++)
			for (k = j; k < n; k++)
			{
				int p1 = j * n + k;
				int p2 = k * n + j;
				double t = RE(input, p1);
				RE(input, p1) = RE(input, p2);
				RE(input, p2) = t;
				t = IM(input, p1);
				IM(input, p1) = IM(input, p2);
				IM(input, p2) = t;
			}
		
		
		for (j = 0; j < n; j++)
		{
