#include <swfft.h>
#include <stdio.h>
#include <athread.h>
#include <math.h>
#include <sys/time.h>
#include "fftw3.h"

inline unsigned long use_for_time1()
{
    struct timeval val;
    gettimeofday(&val,NULL);
    return (val.tv_sec*1000000 + val.tv_usec);
}

unsigned long xMath_exec(int d, int *myn, swfftdComplex* in, swfftdComplex* out, int backward)
{
	unsigned long t1, t2;
	double runtime, gflops;
	DFTI_DESCRIPTOR_HANDLE hDesc;
	DFTI_CONFIG_VALUE lengths[d];
	DFTI_CONFIG_VALUE input_strides[d + 1], output_strides[d + 1];
	int i, datasize = 1;
	long status;
	
	for (i = 0; i < d; i++)
	{
		lengths[i] = myn[i];
	}
	
	if (d == 1)
		status = DftiCreateDescriptor(&hDesc, DFTI_DOUBLE, DFTI_COMPLEX, d, lengths[0]);
	else
		status = DftiCreateDescriptor(&hDesc, DFTI_DOUBLE, DFTI_COMPLEX, d, lengths);

	if(status)
	{
		printf("%s",DftiErrorMessage(status));
		exit(1);
	} 	
	
	input_strides[0] = output_strides[0] = 0;
	for (i = 0; i < d; i++)
	{
		input_strides[d - i] = output_strides[d - i] = datasize;
		datasize *= myn[d - i - 1];
	}
	
	status = DftiSetValue(hDesc, DFTI_INPUT_STRIDES, input_strides);
	status |= DftiSetValue(hDesc, DFTI_OUTPUT_STRIDES, output_strides); 
	status |= DftiSetValue(hDesc, DFTI_PLACEMENT, DFTI_NOT_INPLACE); 
	if(status)
	{
		printf("%s",DftiErrorMessage(status));
		exit(1);
	} 
	
	status = DftiCommitDescriptor(hDesc);
	if(status)
	{
		printf("%s",DftiErrorMessage(status));
		exit(1);
	}
	
	t1 = use_for_time1();
	if (!backward) status = DftiComputeForward(hDesc, in, out); else status = DftiComputeBackward(hDesc, in, out);	
	t2 = use_for_time1();
	if(status)
	{
		printf("%s",DftiErrorMessage(status));
		exit(1);
	} 
	
	status = DftiFreeDescriptor(&hDesc); 
	if(status)
	{
		printf("%s",DftiErrorMessage(status));
		exit(1);
	}

	return t2 - t1;
	/*gflops = 5.E-09 * (double)datasize * logf((double)datasize) / log(2.) / runtime;
	printf("Compute Time:%.6f Gflops:%.6f\n", runtime, gflops);
*/

}
