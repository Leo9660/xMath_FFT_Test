sw5cc -O2 -host -c myfft_host.c -o myfft_host.o -msimd
sw5cc -O2 -slave -c myfft_slave.c -o myfft_slave.o -msimd
sw5ar cr myfft.a myfft_host.o myfft_slave.o
#-msimd -lm_slave
