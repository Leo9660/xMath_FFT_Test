#include <math.h>
#include "myfft.h"
#include "slave.h"
#include "dma.h"
#include "simd.h"
#include "myfft_cossin.h"

/*#define POS_CHANGE() { \
sj++; \
p1++; \
p2++; \
if (sj == hs) \
{ \
sj = 0; \
si++; \
p1 += hs; \
p2 += hs; \
} \
}*/

/*#define POS_BACK() { \
sj--; \
p1--; \
p2--; \
if (sj < 0) \
{ \
sj = hs - 1; \
si--; \
p1 -= hs; \
p2 -= hs; \
} \
}*/

#define POS_CHANGE_V() { \
p1 += s; \
if (p1 >= n) { \
sj++; \
p1 = sj; \
thetaD += stride; \
wp_re = get_cos(thetaD); \
wp_im = -get_sin(thetaD); \
} \
}

__thread_local __attribute__((aligned (128))) double* input, *w;

double get_sin(int n)
{
	if (n < 512) return mysin[n];
	return mycos[n - 512];
	//if (n < 1024) return mycos[n - 512];
	//if (n < 1536) return -mysin[n - 1024];
	//return -mycos[n - 1536];
}

double get_cos(int n)
{
	if (n < 512) return mycos[n];
	return -mysin[n - 512];
	//if (n < 1024) return -mysin[n - 512];
	//if (n < 1536) return -mycos[n - 1024];
	//return mysin[n - 1536];
}

double my_sin2_(int n, int base, double x0, double xx0)
{
	double delta = n * x0 - base * xx0;
	double r1 = mysin[base], r2 = mycos[base];
	double delta2 = delta * delta;
	return r1 + r2 * delta - r1 * delta2 / 2 - r2 * delta2 * delta / 6;
}

double my_cos2_(int n, int base, double x0, double xx0)
{
	double delta = n * x0 - base * xx0;
	double r1 = mysin[base], r2 = mycos[base];
	double delta2 = delta * delta;
	return r2 - r1 * delta - r2 * delta2 / 2 + r1 * delta2 * delta / 6;
}

double my_sin2(int n, int base, double x0, double xx0, int N)
{
	int n4 = N / 4;
	if (n < n4) return my_sin2_(n, base, x0, xx0);
	if (n < 2 * n4) return my_cos2_(n - n4, base - 512, x0, xx0);
	if (n < 3 * n4) return -my_sin2_(n - 2 * n4, base - 1024, x0, xx0);
	return -my_cos2_(n - 3 * n4, base - 1536, x0, xx0);
}

double my_cos2(int n, int base, double x0, double xx0, int N)
{
	int n4 = N / 4;
	if (n < n4) return my_cos2_(n, base, x0, xx0);
	if (n < 2 * n4) return -my_sin2_(n - n4, base - 512, x0, xx0);
	if (n < 3 * n4) return -my_cos2_(n - 2 * n4, base - 1024, x0, xx0);
	return my_sin2_(n - 3 * n4, base - 1536, x0, xx0);
}

inline unsigned long slave_use_for_time()
{
    struct timeval val;
    gettimeofday(&val,NULL);
    return (val.tv_sec*1000000 + val.tv_usec);
}

/*void myF(int n, int s, double* x)
{
	//if (id == 0) printf("n %d q %d\n", n, q);
	if (s > 1)
	{	
		int m = s / 2;
		int stride = 2048 / s;
		int i, j = 0;
		//int msize = m * sizeof(double);
		//lwr = (__thread_local double*)ldm_malloc(msize);
		//lwi = (__thread_local double*)ldm_malloc(msize);
		//for (i = 0; i < m; i++)
		//{
		//	lwr[i] = get_cos(j);
		//	lwi[i] = -get_sin(j);
		//	j += stride;
		//}

		//Serial
		int hs = s / 2;
		int sj, ns = n / s, thetaD = 0;
		//for (i = 0; i < n / 2; i++)
		//{
		for (sj = 0; sj < hs; sj++)
		{
			const double wp_re = get_cos(thetaD),
			wp_im = -get_sin(thetaD);
			thetaD += stride;
			int p1 = sj, p2 = sj + hs;
			while (p2 < n)
			{
				const double a_re = RE(x, p1),
				a_im = IM(x, p1),
				b_re = RE(x, p2),
				b_im = IM(x, p2);
				
				RE(x, p1) = a_re + b_re;
				IM(x, p1) = a_im + b_im;
				
				const double t_re = a_re - b_re,
				t_im = a_im - b_im;
				
				RE(x, p2) = t_re * wp_re - t_im * wp_im;
				IM(x, p2) = t_re * wp_im + t_im * wp_re;
				
				p1 += s;
				p2 += s;
				
				//if (sj == hs)
				//{
					//sj = 0;
					//p1 += hs;
					//p2 += hs;
				//tri = 0;
				//}
			}
		}
		//ldm_free(lwr, msize);
		//ldm_free(lwi, msize);
		myF(n, m, x);
	}	
}*/

void myF_v4(int n, int s, double *x);
void myF_v4v(int n, int s, double *x);

void bit_reverse(int n, double* x)
{
	int i, j, k;
	for (i = 0, j = 1; j < n - 1; j++)
	{
		for (k = n >> 1; k > (i ^= k); k >>= 1);
		if (i < j)
		{
			double t = RE(x, i);
			RE(x, i) = RE(x, j);
			RE(x, j) = t;
			t = IM(x, i);
			IM(x, i) = IM(x, j);
			IM(x, j) = t;
		}
	}
}

void bit_reverse_v(int n, double* x)
{
	int i, j, k;
	for (i = 0, j = 1; j < n - 1; j++)
	{
		for (k = n >> 1; k > (i ^= k); k >>= 1);
		if (i < j)
		{
			double t = R(x, i);
			R(x, i) = R(x, j);
			R(x, j) = t;
			t = I(x, i, n);
			I(x, i, n) = I(x, j, n);
			I(x, j, n) = t;
		}
	}
}

void myfft_slave(double **args)
{
	int id = athread_get_id(-1);
	int dimension = *((int*)args[3]);
	int size = *((int*)args[2]);
	int N = size * size;
	int offset = id * size;
	int length = size * 2 * sizeof(double);
	unsigned long t1, t2;
	int start, pos;

	//w = (double*)ldm_malloc(length / 2);

	/*if (id == 0)
	{
		doublev4 tt = simd_set_doublev4(1, 2, 3, 4);
		//printf("%f", ((int256)tt >> 64) & 0x1111111111111111);
		printf("%f", (int256)tt);
	}*/
	if (dimension == 1)
	{
		//printf("%d %d", id ,start + offset);
		input = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length);
		
		int status = 0;
		volatile unsigned long reply = 0;
		dma_desc __da__=0;
		dma_set_op(&__da__, DMA_GET);
		dma_set_mode(&__da__, PE_MODE);
		dma_set_size(&__da__, length);
		dma_set_reply(&__da__, &reply);
		dma(__da__, args[0] + pos, input);
		dma_wait(&reply, 1);
	
		//penv_slave0_cycle_count(&t1);
		//convert_f(size, input, w);

		myF_v4v(size, size, input);

		//w = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length / 2);
		bit_reverse_v(size, input);
		//bit_reverse_vv(size, 1, input + size, w, size / 2);
		//ldm_free(w, length / 2);
		//penv_slave0_cycle_count(&t2);
		/*int i;
		for (i = 0; i < size; i++)
		{
			double t;
			t = RE(input, i + size / 2);
			RE(input, i) = IM(input, size - i);
			t = IM(input, i + size / 2);
			IM(input, i) = RE(input, size - i);
		}*/

		reply = 0;
		dma_set_op(&__da__, DMA_PUT);
		dma(__da__, args[1] + pos, input);
		dma_wait(&reply, 1);
		ldm_free(input, length);
	}
	
	if (dimension == 2)
	{
		input = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length);
		volatile unsigned long reply = 0;
		dma_desc __da__=0;
		dma_set_mode(&__da__, PE_MODE);
		dma_set_size(&__da__, length / 2);
		dma_set_reply(&__da__, &reply);
		int i;
		
		for (start = offset; start < N; start += 64*size)
		{
			reply = 0;
			/*for (i = 0; i < 64; i++)
			{
				if (id == i) printf("%d %d", start, length);
			}*/
			pos = start;
	
			dma_set_op(&__da__, DMA_GET);
			dma(__da__, args[0] + pos, input);
			dma(__da__, args[0] + pos + N, input + size);
			dma_wait(&reply, 2);

			myF_v4v(size, size, input);
			bit_reverse_v(size, input);

			reply = 0;
			dma_set_op(&__da__, DMA_PUT);
			dma(__da__, args[1] + pos, input);
			dma(__da__, args[1] + pos + N, input + size);
			dma_wait(&reply, 2);
		}
		/*if (id == 0)
		{
			printf("%.2f + %.2fi", )
		}*/
		ldm_free(input, length);
	}
	//ldm_free(w, length / 2);
	//if (id == 0) printf("Calculating time:%f\n", (t2 - t1) / FRE);
}	

void myfft_transpose(double **args)
{
	int id = athread_get_id(-1);
	int size = *((int*)args[2]);
	int multiple = *((int*)args[3]);
	int n = TRANSPOSE_SIZE;
	int n2 = n * n;
	int N = size * size;
	int bnpr = size / n;
	int bn = bnpr * bnpr;
	int i, j, k;
	int length = n * n * sizeof(double) * 2;
	int len_one = n * sizeof(double) * 2;

	input = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length);

	volatile unsigned long reply = 0;
	dma_desc __da__ = 0;
	dma_set_mode(&__da__, PE_MODE);
	dma_set_size(&__da__, len_one / 2);
	dma_set_reply(&__da__, &reply);
	if (multiple) w = (__thread_local  __attribute__((aligned (128))) double*)ldm_malloc(length);
	for (i = id; i < bn; i += 64)
	{
		//printf("%d\n", i);
		int row = i / bnpr;
		int col = i % bnpr;
		//int pos1 = (row * n * size + col * n) * 2;
		//int pos2 = (col * n * size + row * n) * 2;
		int pos1 = row * n * size + col * n;
		int pos2 = col * n * size + row * n;
		if (!multiple)
		{
			dma_set_op(&__da__, DMA_GET);
			reply = 0;
			for (j = 0; j < n; j++)
			{
				int offset = j * n;
				int Offset = j * size;
				dma(__da__, args[0] + pos1 + Offset, input + offset);
				dma(__da__, args[0] + pos1 + Offset + N, input + offset + n2);
			}
			dma_wait(&reply, 2 * n);
			
			for (j = 0; j < n; j++)
				for (k = j; k < n; k++)
				{
					int p1 = j * n + k;
					int p2 = k * n + j;
					double t = R(input, p1);
					R(input, p1) = R(input, p2);
					R(input, p2) = t;
					t = I(input, p1, n2);
					I(input, p1, n2) = I(input, p2, n2);
					I(input, p2, n2) = t;
				}
		}
		else
		{
			dma_set_op(&__da__, DMA_GET);
			reply = 0;

			for (j = 0; j < n; j++)
			{
				int offset = j * n;
				int Offset = j * size;
				dma(__da__, args[0] + pos1 + Offset, input + offset);
				dma(__da__, args[0] + pos1 + Offset + N, input + offset + n2);
			}
			
			double x0 = 2 * M_PI / N;
			double xx0 = 2 * M_PI / 2048;
			double scale = 1.0 * 2048 / N;
			int r_off = row * n, c_off = col * n;
			for (j = 0; j < n; j++)
			{
				int jj = r_off + j;
				for (k = 0; k < n; k++)
				{
					int kk = c_off + k;
					int n0 = jj * kk;
					int base = (int)(n0 * scale + 0.5);
					R(w, j * n + k) = my_cos2(n0, base, x0, xx0, N);
					I(w, j * n + k, n2) = -my_sin2(n0, base, x0, xx0, N);
				}
			}

			dma_wait(&reply, 2 * n);
			
			for (j = 0; j < n; j++)
				for (k = j; k < n; k++)
				{
					int p1 = j * n + k;
					int p2 = k * n + j;
					double tr1 = R(input, p1),
					tr2 = R(input, p2),
					ti1 = I(input, p1, n2),
					ti2 = I(input, p2, n2),
					wr1 = R(w, p1),
					wi1 = I(w, p1, n2),
					wr2 = R(w, p2),
					wi2 = I(w, p2, n2);

					R(input, p2) = tr1 * wr1 - ti1 * wi1;
					I(input, p2, n2) = ti1 * wr1 + tr1 * wi1;
					R(input, p1) = tr2 * wr2 - ti2 * wi2;
					I(input, p1, n2) = ti2 * wr2 + tr2 * wi2;
				}
		}

		reply = 0;
		dma_set_op(&__da__, DMA_PUT);
		for (j = 0; j < n; j++)
		{
			int offset = j * n;
			int Offset = j * size;
			dma(__da__, args[1] + pos2 + Offset, input + offset);
			dma(__da__, args[1] + pos2 + Offset + N, input + offset + n2);
		}
		dma_wait(&reply, 2 * n);
	}
	
	ldm_free(input, length);
	ldm_free(w, length);
}

void myF_v4v(int n, int s, double *x)
{	
	int id = athread_get_id(-1);
	if (s == 2)
	{
		int m = s / 2;
		int stride = 2048 / s;
		int i, j = 0;
		int hs = s / 2;
		int sj, ns = n / s, thetaD = 0;
		for (sj = 0; sj < hs; sj++)
		{
			const double wp_re = get_cos(thetaD),
			wp_im = -sqrt(1 - wp_re * wp_re);
			thetaD += stride;
			int p1 = sj, p2 = sj + hs;
			while (p2 < n)
			{
				const double a_re = R(x, p1),
				a_im = I(x, p1, n),
				b_re = R(x, p2),
				b_im = I(x, p2, n);
				
				R(x, p1) = a_re + b_re;
				I(x, p1, n) = a_im + b_im;
				
				const double t_re = a_re - b_re,
				t_im = a_im - b_im;
				
				R(x, p2) = t_re * wp_re - t_im * wp_im;
				I(x, p2, n) = t_re * wp_im + t_im * wp_re;
				
				p1 += s;
				p2 += s;
			}
		}
	}
	else if (s >= 4)
	{
		int m = s / 4,
		m2 = s / 2,
		m3 = m + m2;
		int stride = 2048 / s;
		int sj;
		int off21 = m * stride;
		int theta1 = 0;
		if (s > 8)
		{
			//Vectorize
			int d1 = stride, d2 = d1 + d1, d3 = d2 + d1, d4 = d2 + d2;
			for (sj = 0; sj < m; sj += 4)
			{
				int p1 = sj, p2 = p1 + m,
				p3 = p1 + m2, p4 = p1 + m3;
				
				double wr_1, wr_2, wr_3, wr_4;
				doublev4 wr1, wr2, wr3, wi1, wi2, wi3, wr4, wi4;
				wr_1 = get_cos(theta1); wr_2 = get_cos(theta1 + d1);
				wr_3 = get_cos(theta1 + d2); wr_4 = get_cos(theta1 + d3);

				wr1 = simd_set_doublev4(wr_1, wr_2, wr_3, wr_4);
				//wr_1 = -sqrt(1 - wr_1 * wr_1);
				//wr_2 = -sqrt(1 - wr_2 * wr_2);
				//wr_3 = -sqrt(1 - wr_3 * wr_3);
				//wr_4 = -sqrt(1 - wr_4 * wr_4);

				wi1 = simd_set_doublev4(1, 1, 1, 1) - wr1 * wr1;
				wi1 = -simd_vsqrtd(wi1);
				wr2 = wi1;
				wi2 = -wr1;
				wr3 = wr1 * wr1 - wi1 * wi1;
				wi3 = wr1 * wi1 * 2;
				
				/*if (id == 0)
				{
					printf("test:\n");
					simd_print_doublev4(wr1);
					simd_print_doublev4(wi1);
					simd_print_doublev4(wr2);
					simd_print_doublev4(wi2);
					simd_print_doublev4(wr3);
					simd_print_doublev4(wi3);
				}*/				

				while (p1 < n)
				{
					doublev4 r1, r2, r3, r4,
					i1, i2, i3, i4;
					simd_load(r1, &(R(x, p1)));
					simd_load(i1, &(I(x, p1, n)));
					simd_load(r2, &(R(x, p2)));
					simd_load(i2, &(I(x, p2, n)));
					simd_load(r3, &(R(x, p3)));
					simd_load(i3, &(I(x, p3, n)));
					simd_load(r4, &(R(x, p4)));
					simd_load(i4, &(I(x, p4, n)));

					/*double r1 = R(x, p1),
					i1 = I(x, p1, n),
					r2 = R(x, p2),
					i2 = I(x, p2, n),
					r3 = R(x, p3),
					i3 = I(x, p3, n),
					r4 = R(x, p4),
					i4 = I(x, p4, n);*/
					
					/* before optimization*/
 					doublev4 tr, ti;				
					tr = r1 - r3;
					ti = i1 - i3;
					
					r1 = r1 + r3;
					i1 = i1 + i3;
					r3 = tr * wr1 - ti * wi1;
					i3 = tr * wi1 + ti * wr1;

					tr = r2 - r4;
					ti = i2 - i4;
					
					r2 = r2 + r4;
					i2 = i2 + i4;
					r4 = tr * wr2 - ti * wi2;
					i4 = tr * wi2 + ti * wr2;

					tr = r1 - r2;
					ti = i1 - i2;

					r1 = r1 + r2;
					i1 = i1 + i2;
					r2 = tr * wr3 - ti * wi3;
					i2 = tr * wi3 + ti * wr3;

					tr = r3 - r4;
					ti = i3 - i4;

					r3 = r3 + r4;
					i3 = i3 + i4;
					r4 = tr * wr3 - ti * wi3;
					i4 = tr * wi3 + ti * wr3;
					
					simd_store(r1, &(R(x, p1)));
					simd_store(i1, &(I(x, p1, n)));
					simd_store(r2, &(R(x, p2)));
					simd_store(i2, &(I(x, p2, n)));
					simd_store(r3, &(R(x, p3)));
					simd_store(i3, &(I(x, p3, n)));
					simd_store(r4, &(R(x, p4)));
					simd_store(i4, &(I(x, p4, n)));
				
					/*R(x, p1) = r1;
					I(x, p1, n) = i1;
					R(x, p2) = r2;
					I(x, p2, n) = i2;
					R(x, p3) = r3;
					I(x, p3, n) = i3;
					R(x, p4) = r4;
					I(x, p4, n) = i4;*/

					p1 += s;
					p2 += s;
					p3 += s;
					p4 += s;
				}
				theta1 += d4;
			}
		}
		else
		{	
			for (sj = 0; sj < m; sj++)
			{
				int p1 = sj, p2 = p1 + m,
				p3 = p1 + m2, p4 = p1 + m3;
				double wr1, wr2, wr3, wi1, wi2, wi3, wr4, wi4, wr5, wi5;
				wr1 = get_cos(theta1);
				wi1 = -sqrt(1 - wr1 * wr1);//-get_sin(theta1);
				wr2 = wi1;
				wi2 = -wr1;//-sqrt(1 - wr2 * wr2);//-get_sin(theta2);
				wr3 = wr1 * wr1 - wi1 * wi1;//get_cos(theta3);
				wi3 = wr1 * wi1 * 2;//-get_sin(theta3);

				while (p1 < n)
				{
					double r1 = R(x, p1),
					i1 = I(x, p1, n),
					r2 = R(x, p2),
					i2 = I(x, p2, n),
					r3 = R(x, p3),
					i3 = I(x, p3, n),
					r4 = R(x, p4),
					i4 = I(x, p4, n);
					
					/* before optimization*/
 					double tr, ti;				
					tr = r1 - r3;
					ti = i1 - i3;
					
					r1 = r1 + r3;
					i1 = i1 + i3;
					r3 = tr * wr1 - ti * wi1;
					i3 = tr * wi1 + ti * wr1;

					tr = r2 - r4;
					ti = i2 - i4;
					
					r2 = r2 + r4;
					i2 = i2 + i4;
					r4 = tr * wr2 - ti * wi2;
					i4 = tr * wi2 + ti * wr2;

					tr = r1 - r2;
					ti = i1 - i2;

					r1 = r1 + r2;
					i1 = i1 + i2;
					r2 = tr * wr3 - ti * wi3;
					i2 = tr * wi3 + ti * wr3;

					tr = r3 - r4;
					ti = i3 - i4;

					r3 = r3 + r4;
					i3 = i3 + i4;
					r4 = tr * wr3 - ti * wi3;
					i4 = tr * wi3 + ti * wr3;
					
					R(x, p1) = r1;
					I(x, p1, n) = i1;
					R(x, p2) = r2;
					I(x, p2, n) = i2;
					R(x, p3) = r3;
					I(x, p3, n) = i3;
					R(x, p4) = r4;
					I(x, p4, n) = i4;

					p1 += s;
					p2 += s;
					p3 += s;
					p4 += s;
				}
				theta1 += stride;
			}
		}
		myF_v4v(n, m, x);
	}
}

void myF_v4(int n, int s, double *x)
{
	if (s == 2)
	{
		int m = s / 2;
		int stride = 2048 / s;
		int i, j = 0;

		//Serial
		int hs = s / 2;
		int sj, ns = n / s, thetaD = 0;
		for (sj = 0; sj < hs; sj++)
		{
			const double wp_re = get_cos(thetaD),
			wp_im = -sqrt(1 - wp_re * wp_re);
			thetaD += stride;
			int p1 = sj, p2 = sj + hs;
			while (p2 < n)
			{
				const double a_re = RE(x, p1),
				a_im = IM(x, p1),
				b_re = RE(x, p2),
				b_im = IM(x, p2);
				
				RE(x, p1) = a_re + b_re;
				IM(x, p1) = a_im + b_im;
				
				const double t_re = a_re - b_re,
				t_im = a_im - b_im;
				
				RE(x, p2) = t_re * wp_re - t_im * wp_im;
				IM(x, p2) = t_re * wp_im + t_im * wp_re;
				
				p1 += s;
				p2 += s;
				
				/*if (sj == hs)
				{
					sj = 0;
					p1 += hs;
					p2 += hs;
				//tri = 0;
				}*/
			}
		}
	}
	else if (s >= 4)
	{
		int m = s / 4,
		m2 = s / 2,
		m3 = m + m2;
		int stride = 2048 / s;
		int sj;
		int off21 = m * stride;
		int theta1 = 0, theta2, theta3;
		for (sj = 0; sj < m; sj++)
		{
			int p1 = sj, p2 = p1 + m,
			p3 = p1 + m2, p4 = p1 + m3;
			theta2 = off21 + theta1;
			theta3 = theta1 + theta1;
			/*int theta1 = sj * stride,
			theta2 = m * stride + theta1,
			theta3 = 2 * theta1;*/
			double wr1, wr2, wr3, wi1, wi2, wi3, wr4, wi4, wr5, wi5;
			wr1 = get_cos(theta1);
			wi1 = -sqrt(1 - wr1 * wr1);//-get_sin(theta1);
			wr2 = wi1;
			wi2 = -wr1;//-sqrt(1 - wr2 * wr2);//-get_sin(theta2);
			wr3 = wr1 * wr1 - wi1 * wi1;//get_cos(theta3);
			wi3 = wr1 * wi1 * 2;//-get_sin(theta3);
			/*wr4 = wr1 * wr3 - wi1 * wi3;
			wi4 = wr1 * wi3 + wi1 * wr3;
			wr5 = wr2 * wr3 - wi2 * wi3;
			wi5 = wr2 * wi3 + wi2 * wr3;*/

			while (p1 < n)
			{
				double r1 = RE(x, p1),
				i1 = IM(x, p1),
				r2 = RE(x, p2),
				i2 = IM(x, p2),
				r3 = RE(x, p3),
				i3 = IM(x, p3),
				r4 = RE(x, p4),
				i4 = IM(x, p4);
				
				/*double cr1, cr2, cr3, cr4,
				ci1, ci2, ci3, ci4;

				cr1 = r1 + r3;
				ci1 = i1 + i3;
				cr2 = r2 + r4;
				ci2 = i2 + i4;
				cr3 = r1 - r3;
				ci3 = i1 - i3;
				cr4 = r2 - r4;
				ci4 = i2 - i4;*/
				
				/* before optimization*/
 				double tr, ti;				
				tr = r1 - r3;
				ti = i1 - i3;
				
				r1 = r1 + r3;
				i1 = i1 + i3;
				r3 = tr * wr1 - ti * wi1;
				i3 = tr * wi1 + ti * wr1;

				tr = r2 - r4;
				ti = i2 - i4;
				
				r2 = r2 + r4;
				i2 = i2 + i4;
				r4 = tr * wr2 - ti * wi2;
				i4 = tr * wi2 + ti * wr2;

				tr = r1 - r2;
				ti = i1 - i2;

				r1 = r1 + r2;
				i1 = i1 + i2;
				r2 = tr * wr3 - ti * wi3;
				i2 = tr * wi3 + ti * wr3;

				tr = r3 - r4;
				ti = i3 - i4;

				r3 = r3 + r4;
				i3 = i3 + i4;
				r4 = tr * wr3 - ti * wi3;
				i4 = tr * wi3 + ti * wr3;
				
				/* only for test
 				r1 = r1 + r2;
				i1 = i1 + i2;
				r2 = r3 + r2;
				i2 = i4 - i2;
				r3 = r1 + i2;
				i3 = i1 * i2;
				r4 = r1 * r2;
				i4 = i4 - i2;*/

				/*double tr, ti;
				r1 = cr1 + cr2;
				i1 = ci1 + ci2;
				tr = cr1 - cr2;
				ti = ci1 - ci2;
				r2 = tr * wr3 - ti * wi3;
				i2 = tr * wi3 + ti * wr3;
				r3 = cr3 * wr1 - ci3 * wi1 + cr4 * wr2 - ci4 * wi2;
				i3 = cr3 * wi1 + ci3 * wr1 + cr4 * wi2 + ci4 * wr2;
				r4 = cr3 * wr4 - ci3 * wi4 - cr4 * wr5 + ci4 * wi5;
				i4 = cr3 * wi4 + ci3 * wr4 - cr4 * wi5 - ci4 * wr5;
				*/
				
				RE(x, p1) = r1;
				IM(x, p1) = i1;
				RE(x, p2) = r2;
				IM(x, p2) = i2;
				RE(x, p3) = r3;
				IM(x, p3) = i3;
				RE(x, p4) = r4;
				IM(x, p4) = i4;

				p1 += s;
				p2 += s;
				p3 += s;
				p4 += s;
			}
			theta1 += stride;
		}
		myF_v4(n, m, x);
	}
}

void myfft_eightstep(double **args)
{
	int id = athread_get_id(-1);
	double *re_in = args[0],
	*im_in = args[1],
	*output = args[2];
	int N = *((int*)args[3]);
	int n = N / 2;
	int start;
	int stride = n / 64;
	if (n > MAX_N) stride = MAX_N;
	
	length = stride * sizeof(double) * 2;
	input = (__thread_local double*)ldm_malloc(length);
	volatile unsigned long reply = 0;
	dma_desc __da__ = 0;
	dma_set_op(&__da__, DMA_GET);
	dma_set_mode(&__da__, PE_MODE);
	dma_set_size(&__da__, length / 2);
	dma_set_reply(&__da__, &reply);

	for (start = id * MAX_N; start < n; start += stride)
	{
		dma(__da__, re_in + start, input);
		dma(__da__, im_in + start, input + stride);
		dma_wait(&reply, 2);
		int m = n / 2;
		
	}

	ldm_free(input, length);
}

/*void myF_v(int n, int s, double* x)
{
	//if (id == 0) printf("n %d q %d\n", n, q);
	if (s > 1)
	{	
		int m = s / 2;
		int stride = 2048 / s;
		int i, j = 0;
		int s1 = s, s2 = s1 + s1, s3 = s2 + s1, s4 = s2 + s2;

		//Vectorize
		int hs = s / 2;
		int sj, ns = n / s, thetaD = 0;
		for (sj = 0; sj < hs; sj++)
		{
			const double wp_re = get_cos(thetaD),
			wp_im = -get_sin(thetaD);
			thetaD += stride;
			int p1 = sj, p2 = sj + hs;
				
			if (ns < 4)
			{
				while (p2 < n)
				{
					const double a_re = RE(x, p1),
					a_im = IM(x, p1),
					b_re = RE(x, p2),
					b_im = IM(x, p2);

					RE(x, p1) = a_re + b_re;
					IM(x, p1) = a_im + b_im;

					const double t_re = a_re - b_re,
					t_im = a_im - b_im;
			
					RE(x, p2) = t_re * wp_re - t_im * wp_im;
					IM(x, p2) = t_re * wp_im + t_im * wp_re;
				
					p1 += s;
					p2 += s;	
				}
			}
			else
			{
				doublev4 wr, wi;
				wr = simd_set_doublev4(wp_re, wp_re, wp_re, wp_re);				
				wi = simd_set_doublev4(wp_im, wp_im, wp_im, wp_im);
				while (p2 < n)
				{
					doublev4 ar, ai, br, bi, r1r, r1i, r2r, r2i, tr, ti;
					ar = simd_set_doublev4(RE(x, p1), RE(x, p1 + s1), RE(x, p1 + s2), RE(x, p1 + s3));
					ai = simd_set_doublev4(IM(x, p1), IM(x, p1 + s1), IM(x, p1 + s2), IM(x, p1 + s3));
					br = simd_set_doublev4(RE(x, p2), RE(x, p2 + s1), RE(x, p2 + s2), RE(x, p2 + s3));
					bi = simd_set_doublev4(IM(x, p2), IM(x, p2 + s1), IM(x, p2 + s2), IM(x, p2 + s3));
					
					r1r = simd_vaddd(ar, br);
					r1i = simd_vaddd(ai, bi);
			
					tr = simd_vsubd(ar, br);
					ti = simd_vsubd(ai, bi);

					r2r = simd_vmuld(ti, wi);
					r2r = simd_vmsd(tr, wr, r2r);
					r2i = simd_vmuld(tr, wi);
					r2i = simd_vmad(ti, wr, r2i);
					
					simd_store(r1r, w);
					RE(x, p1) = w[0];
					RE(x, p1 + s1) = w[1];
					RE(x, p1 + s2) = w[2];
					RE(x, p1 + s3) = w[3];
					simd_store(r1i, w);
					IM(x, p1) = w[0];
					IM(x, p1 + s1) = w[1];
					IM(x, p1 + s2) = w[2];
					IM(x, p1 + s3) = w[3];
					simd_store(r2r, w);
					RE(x, p2) = w[0];
					RE(x, p2 + s1) = w[1];
					RE(x, p2 + s2) = w[2];
					RE(x, p2 + s3) = w[3];
					simd_store(r2i, w);
					IM(x, p2) = w[0];
					IM(x, p2 + s1) = w[1];
					IM(x, p2 + s2) = w[2];
					IM(x, p2 + s3) = w[3];
					
					p1 += s4;
					p2 += s4;
				}
			}
		}
		myF_v(n, m, x);
	}	
}
*/

/*
void myF_v(int n, int s, double* x)
{
	//if (id == 0) printf("n %d q %d\n", n, q);
	if (s > 1)
	{	
		int m = s / 2;
		int stride = 2048 / s;
		int i, j = 0;

		//Serial
		int hs = s / 2;
		int sj = 0, p1 = 0, p2, ns = n / s, thetaD = 0;
		double wp_re = get_cos(thetaD),
		wp_im = -get_sin(thetaD);

		for (i = 0; i < n / 2; i++)
		{
			p2 = p1 + hs;
			const double a_re = RE(x, p1),
			a_im = IM(x, p1),
			b_re = RE(x, p2),
			b_im = IM(x, p2);
			
			RE(x, p1) = a_re + b_re;
			IM(x, p1) = a_im + b_im;
				
			const double t_re = a_re - b_re,
			t_im = a_im - b_im;
				
			RE(x, p2) = t_re * wp_re - t_im * wp_im;
			IM(x, p2) = t_re * wp_im + t_im * wp_re;
				
			POS_CHANGE_V();
		}
		myF_v(n, m, x);
	}
}			
*/

		/*
		//Vectorize
		int i, hs = s / 2;
		int p1 = 0, p2 = hs, si = 0, sj = 0;
		for (i = 0; i < n / 2; i += 4)
		{
			doublev4 ar, br, ai, bi,
			r1r, r1i, r2r, r2i;
			double ar1, ar2, ar3, ar4,
			br1, br2, br3, br4,
			ai1, ai2, ai3, ai4,
			bi1, bi2, bi3, bi4,
			wr1, wr2, wr3, wr4,
			wi1, wi2, wi3, wi4;
			
			ar1 = RE(x, p1);
			br1 = RE(x, p2);
			ai1 = IM(x, p1);
			bi1 = IM(x, p2);
			wr1 = cos(sj * theta0);
			wi1 = -sin(sj * theta0);
			POS_CHANGE();
			
			ar2 = RE(x, p1);
			br2 = RE(x, p2);
			ai2 = IM(x, p1);
			bi2 = IM(x, p2);
			wr2 = cos(sj * theta0);
			wi2 = -sin(sj * theta0);
			POS_CHANGE();
					
			ar3 = RE(x, p1);
			br3 = RE(x, p2);
			ai3 = IM(x, p1);
			bi3 = IM(x, p2);
			wr3 = cos(sj * theta0);
			wi3 = -sin(sj * theta0);
			POS_CHANGE();

			ar4 = RE(x, p1);
			br4 = RE(x, p2);
			ai4 = IM(x, p1);
			bi4 = IM(x, p2);
			wr4 = cos(sj * theta0);
			wi4 = -sin(sj * theta0);
			wr4 = vsin(wr4);

			ar = simd_set_doublev4(ar1, ar2, ar3, ar4);
			br = simd_set_doublev4(br1, br2, br3, br4);
			ai = simd_set_doublev4(ai1, ai2, ai3, ai4);
			bi = simd_set_doublev4(bi1, bi2, bi3, bi4);
			
			r1r = simd_vaddd(ar, br);
			r1i = simd_vaddd(ai, bi);
			
			//simd_print_doublev4(r1r);
			
			doublev4 wr, wi;
			wr = simd_set_doublev4(wr1, wr2, wr3, wr4);
			wi = simd_set_doublev4(wi1, wi2, wi3, wi4);

			wr = vsin(wr);			
			doublev4 tr, ti;
			tr = simd_vsubd(ar, br);
			ti = simd_vsubd(ai, bi);
			
			r2r = simd_vmuld(ti, wi);
			r2r = simd_vmsd(tr, wr, r2r);

			r2i = simd_vmuld(tr, wi);
			r2i = simd_vmad(ti, wr, r2i);

			simd_store(r1r, wa1r);
			simd_store(r1i, wa1i);
			
			simd_store(r2r, wa2r);
			simd_store(r2i, wa2i);
			
			int j;
			for (j = 0; j < 4; j++)
			{
				RE(x, p1) = wa1r[j];
				IM(x, p1) = wa1i[j];
				RE(x, p2) = wa2r[j];
				IM(x, p2) = wa2i[j];
				POS_BACK();
			}
			//printf("%f + %fi", RE(x, p1), IM(x, p1));
			for (j = 0; j < 4; j++)
				POS_CHANGE();

}*/
		
/*void bit_reverse_vv(int n, int s, double *x, double *y, int N_2)
{
	if (n > 2)
	{
		int m = n / 2;
		int i, j;
		int s2 = 2 * s;
		if (s < 4)
		{	
			for (i = 0; i < m; i++)
			{
				int p1 = 0, pp1 = 0;
				for (j = 0; j < s; j++)
				{
					double a = x[j + p1],
					b = x[j + p1 + N_2];
					y[j + pp1] = a;
					y[j + pp1 + s] = b;
				}
				p1 += s;
				pp1 += s2;
			}
			bit_reverse_vv(n / 2, 2 * s, y, x, N_2);
		}
		else
		{
			for (i = 0; i < m; i++)
			{
				int p1 = 0, pp1 = 0;
				for (j = 0; j < s; j += 4)
				{
					doublev4 a, b;
					simd_load(a, x + j + p1);
					simd_load(b, x + j + p1 + N_2);
					simd_store(a, x + j + pp1);
					simd_store(b, x + j + pp1 + s);
				}
				p1 += s;
				pp1 += s2;
			}
			bit_reverse_vv(n / 2, 2 * s, y, x, N_2);
		}
	}
}*/

/*void convert_f(int n, double *x, double *w)
{
	int i;
	for (i = 0; i < n; i++)
	{
		w[i] = RE(x, j);
	}
	for (i = 0; i < n; i++)
	{
		x[i] = RE(x, i);
	}
	for (i = 0; i < n ; i++)
	{
		x[i + n] = w[i];
	}
}*/

/*void convert_b(int n, double *x, double *w)
{
	int i;
	for (i = 0; i < n; i++)
	{
		
	}
}*/

