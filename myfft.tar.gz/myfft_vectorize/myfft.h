#ifndef MY_FFT__
#define MY_FFT__

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <sys/time.h>

#define FFT_FORWARD 0
#define FFT_BACKWARD 1

#define RE(x, y) x[(y) * 2]
#define IM(x, y) x[(y) * 2 + 1]

#define R(x, y) x[(y)]
#define I(x, y, z) x[(y) + (z)]

#define MAX_N 2048

#define TRANSPOSE_SIZE 32

#define P_NUM 64

#define US 1000000.0
#define FRE 1200000000.0
/*#define A_DMA_IGET(mode,src,dest,len,re_addr) \
({ \
dma_desc __da__=0; \
dma_set_op(&__da__, DMA_GET); \
dma_set_mode(&__da__, mode); \
dma_set_size(&__da__, len); \
dma_set_reply(&__da__, re_addr); \
dma(__da__, src, dest); \
})*/

int myfft_hzd(double *in, double *out, int n, int direction);

#endif
