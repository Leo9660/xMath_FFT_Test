sw5cc -O2 -host -c main.c -o main.o
mpicxx -hybrid main.o myfft.a -o myfft libfftw3.a libfftw3_threads.a libgsl.a libgslcblas.a
#sshpass -p 123456 scp myfft root@192.167.253.104:/root/hzd
