#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <swfft.h>
#include <athread.h>
#include "fftw3.h"
#include <sys/time.h>

inline unsigned long use_for_time()
{
    struct timeval val;
    gettimeofday(&val,NULL);
    return (val.tv_sec*1000000 + val.tv_usec);
}

extern swfftdComplex *in1, *out1;
extern fftw_complex *in2, *out2;

void my_check(long datasize)
{
	int i, flag = 1;
	for (i = 0; i < datasize; i++)
	{
		double re1, re2;
		double im1, im2;
		re1 = out1[i].re;
		re2 = out2[i][0];
		im1 = out1[i].im;
		im2 = out2[i][1];
		while (fabs(re1) > 1) re1 /= 10;
		while (fabs(re2) > 1) re2 /= 10;
		while (fabs(im1) > 1) im1 /= 10;
		while (fabs(im2) > 1) im2 /= 10;
		if (fabs(re1 - re2) > 1e-10 || fabs(im1 - im2) > 1e-10 )
		{
			flag = 0;
			printf("Index %d incorrect!\n", i);
			printf("xMath:%.23f+%.23fi\n", out1[i].re, out1[i].im);
			printf("fftw3:%.23f+%.23fi\n", out2[i][0], out2[i][1]);
			break;
		}
	}	
	if (flag) printf("Consensus!\n");

}

int main(int argc, char* argv[])
{
	int dimension = 0;	
	int len = 1;
	int n[3];
	FILE *fout;
	int i, j, k;
	int tp;
	int repeat;
	unsigned long t1, t2;
	long datasize = 1;
	double runtime, gflops, gflops1;
	
	athread_init();

	if (argc < 3 || argc > 5)
	{
		printf("usage: %s [dimension] [n1]([n2] [n3])\n",argv[0]);
		return -1;
	}
	dimension = atoi(argv[1]);
	if (argc != dimension + 2)
	{
		printf("usage: %s [dimension] [n1]([n2] [n3])\n",argv[0]);
		return -1;
	}
	if (dimension < 1||dimension > 3)
	{
		printf("invalid dimension!\n");
		return -1;
	}
	
	for (i = 0; i < dimension; i++)
		n[i] = atoi(argv[i + 2]);	
	fout = fopen("testResult1", "a+");
	fprintf(fout, "%d", n[0]);
	for (i = 1; i < dimension; i++)
		fprintf(fout, "x%d", n[i]);
	fprintf(fout, ",");

	for (i = 0; i < dimension; i++)
		datasize *= n[i];
	
	data_init(dimension, n);
	printf("Data inited!\n");	

	runtime = 0;
	for (repeat = 0; repeat < 10; repeat++)
		runtime += xMath_exec(dimension, n, in1, out1, 0);
	runtime /= 10000000.0;
	gflops = 5.E-09 * (double)datasize * logf((double)datasize) / log(2.) / runtime;
	printf("xMath Forward FFT done!\nTime:%.6f Gflops:%.6f\n", runtime, gflops);
	fprintf(fout, "%.4f,", gflops);
	gflops1 = gflops;	

	t1 = use_for_time();
	fftw3_exec(dimension, n, in2, out2, 0);
	t2 = use_for_time();
	runtime = (t2-t1)/1000000.0;
	gflops = 5.E-09 * (double)datasize * logf((double)datasize) / log(2.) / runtime;
	printf("fftw3 Forward FFT done!\nTime:%.6f Gflops:%.6f\n", runtime, gflops);
	fprintf(fout, "%.2f,", gflops1 / gflops);
	
	my_check(datasize);

	runtime = 0;
	for (repeat = 0; repeat < 10; repeat++)
		runtime += xMath_exec(dimension, n, in1, out1, 1);
	runtime /= 10000000.0;
	gflops = 5.E-09 * (double)datasize * logf((double)datasize) / log(2.) / runtime;
	printf("xMath Backward FFT done!\nTime:%.6f Gflops:%.6f\n", runtime, gflops);
	fprintf(fout, "%.4f,", gflops);
	gflops1 = gflops;	

	t1 = use_for_time();
	fftw3_exec(dimension, n, in2, out2, 1);
	t2 = use_for_time();
	runtime = (t2-t1)/1000000.0;
	gflops = 5.E-09 * (double)datasize * logf((double)datasize) / log(2.) / runtime;
	printf("fftw3 Backward FFT done!\nTime:%.6f Gflops:%.6f\n", runtime, gflops);
	fprintf(fout, "%.2f,", gflops1 / gflops);

	my_check(datasize);	
	fprintf(fout, "\n");
	
	swfftFree(in1);
	swfftFree(out1);
	fftw_free(in2);
	fftw_free(out2);
	fclose(fout);

}
