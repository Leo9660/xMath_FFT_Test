#include "fftw3.h"
#include <stdlib.h>
#include <stdio.h>

void fftw3_exec(int d, int* n, fftw_complex *in, fftw_complex *out, int backward)
{
	fftw_plan p;
	int datasize = 1;
	int i = 0;	

	for (i = 0; i < d; i++)
		datasize *= n[i];	
	
	if (d == 1)
	{
		if (!backward)
			p = fftw_plan_dft_1d(n[0], in, out, FFTW_FORWARD, FFTW_ESTIMATE);
		else
			p = fftw_plan_dft_1d(n[0], in, out, FFTW_BACKWARD, FFTW_ESTIMATE);
		fftw_execute(p);
	}

	if (d == 2)
	{
		if (!backward)
			p = fftw_plan_dft_2d(n[0], n[1], in, out, FFTW_FORWARD, FFTW_ESTIMATE);
		else
			p = fftw_plan_dft_2d(n[0], n[1], in, out, FFTW_BACKWARD, FFTW_ESTIMATE);
		fftw_execute(p);
	}	
	if (d == 3)
	{
		if (!backward)
			p = fftw_plan_dft_3d(n[0], n[1], n[2], in, out, FFTW_FORWARD, FFTW_ESTIMATE);
		else
			p = fftw_plan_dft_3d(n[0], n[1], n[2], in, out, FFTW_BACKWARD, FFTW_ESTIMATE);
		fftw_execute(p);
	}

	fftw_destroy_plan(p);
	
}
