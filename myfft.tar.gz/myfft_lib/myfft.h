#ifndef MY_FFT__
#define MY_FFT__

#include <math.h>

#define RE(x, y) x[(y) * 2]
#define IM(x, y) x[(y) * 2 + 1]

typedef double* myfft_complex;

myfft_complex myfft_malloc(int n);

int myfft_hzd(double *in, double *out, int n);

#endif
