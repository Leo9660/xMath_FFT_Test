#include <stdlib.h>
#include <time.h>
#include <swfft.h>
#include "fftw3.h"

swfftdComplex *in1, *out1; 
fftw_complex *in2, *out2; 

void data_init(int d, int* n)
{
	int i, j, k;
	int tp;
	double rand_x, rand_y;
	int datasize = 1;

	for (i = 0; i < d; i++)
	{	
		datasize *= n[i];
	}
	
	in1 = (swfftdComplex*)swfftMalloc(datasize * sizeof(swfftdComplex), 128);
	out1 = (swfftdComplex*)swfftMalloc(datasize * sizeof(swfftdComplex), 128);

	in2 = (fftw_complex*)fftw_malloc(sizeof(fftw_complex) * datasize);
	out2 = (fftw_complex*)fftw_malloc(sizeof(fftw_complex) * datasize);
	
	srand(time(NULL));
	
	if (d == 1)
	{
		for (i = 0; i < n[0]; i++)
		{
			{
			rand_x = (double)rand()/(RAND_MAX);
			rand_y = sqrt(1 - rand_x*rand_x);
			in1[i].re = rand_x;
			in1[i].im = rand_y;
			in2[i][0] = rand_x;
			in2[i][1] = rand_y;
			}
		}
	}
	if (d == 2)
	{
		for (i = 0; i < n[0]; i++)
		for (j = 0; j < n[1]; j++)
		{
			{
			rand_x = (double)rand()/(RAND_MAX);
                        rand_y = (double)sqrt(1 - rand_x*rand_x);
			tp = i * n[1] + j;
			in1[tp].re = rand_x;
			in1[tp].im = rand_y;
			in2[tp][0] = rand_x;
			in2[tp][1] = rand_y;
			}
		}
	}
	if (d == 3)
	{
		for (i = 0; i < n[0]; i++)
		for (j = 0; j < n[1]; j++)
		for (k = 0; k < n[2]; k++)
		{
			{
			rand_x = (double)rand()/(RAND_MAX);
                        rand_y = (double)sqrt(1 - rand_x*rand_x);
			tp = i * n[1] * n[2] + j * n[2] + k;
			in1[tp].re = rand_x;
			in1[tp].im = rand_y;
			in2[tp][0] = rand_x;
			in2[tp][1] = rand_y;
			}
		}	
	}
}
