rm -rf myfft ./*.o
