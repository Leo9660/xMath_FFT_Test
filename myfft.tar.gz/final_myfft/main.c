#include <stdio.h>
#include <stdlib.h>
#include "myfft.h"
#include "fftw3.h"

fftw_complex *in2, *out2;
myfft_complex in, out;

int main(int argc, char* argv[])
{
	int i = 0;	
	if (argc != 2)
	{
		printf("Usage:%s [N]\n", argv[0]);
		exit(-1);
	}
	int n = atoi(argv[1]);

	in = myfft_malloc(n);
	out = myfft_malloc(n);
	in2 = (fftw_complex*)fftw_malloc(sizeof(fftw_complex) * n);
	out2 = (fftw_complex*)fftw_malloc(sizeof(fftw_complex) * n);

	srand(time(NULL));
	double rand_x, rand_y;
	for (i = 0; i < n; i++)
	{
		rand_x = (double)rand()/(RAND_MAX);
		rand_y = sqrt(1 - rand_x*rand_x);

		RE(in, i) = rand_x;
		IM(in, i) = rand_y;
		in2[i][0] = rand_x;
		in2[i][1] = rand_y;
	}

	myfft_hzd(in, out, n);

	printf("OK! Test!\n");
	fftw_plan p = fftw_plan_dft_1d(n, in2, out2, FFTW_FORWARD, FFTW_ESTIMATE);
        fftw_execute(p);
	fftw_destroy_plan(p);

	for (i = 0; i < n; i++)
	{
		if (fabs(RE(out, i) - out2[i][0]) > 1e-8 || fabs(IM(out, i) - out2[i][1]) > 1e-8)
		{
			printf("Index %d incorrect!\n", i);
			printf("myfft:%.4f+%.4fi", RE(out, i), IM(out, i));
			printf("fftw:%.4f+%.4fi\n", out2[i][0], out2[i][1]);
			break;
		}
	}
}
