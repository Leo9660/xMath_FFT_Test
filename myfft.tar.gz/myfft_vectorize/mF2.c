#include "myfft.h"

#define POS_CHANGE_V() { \
p1 += s; \
p2 += s; \
if (p2 > n) { \
sj++; \
p1 = sj; \
p2 = sj + hs; \
thetaD += stride; \
} \
}

void myF_v(int n, int s, double* x)
{
	//if (id == 0) printf("n %d q %d\n", n, q);
	if (s > 1)
	{	
		int m = s / 2;
		int stride = 2048 / s;
		int i, j = 0;

		//Serial
		int hs = s / 2;
		int sj = 0, p1 = 0, p2 = hs, ns = n / s, thetaD = 0;

		for (i = 0; i < n; i++)
		{
			const double wp_re = get_cos(thetaD),
			wp_im = -get_sin(thetaD);
			const double a_re = RE(x, p1),
			a_im = IM(x, p1),
			b_re = RE(x, p2),
			b_im = IM(x, p2);
			
			RE(x, p1) = a_re + b_re;
			IM(x, p1) = a_im + b_im;
				
			const double t_re = a_re - b_re,
			t_im = a_im - b_im;
				
			RE(x, p2) = t_re * wp_re - t_im * wp_im;
			IM(x, p2) = t_re * wp_im + t_im * wp_re;
				
			POS_CHANGE_V();
		}
		myF_v(n, m, x);
	}
}			

/*void myF2(int n, int s, double *x)
{
	int n0 = 0;
	int n1 = n / 4;
	int n2 = n / 2;
	int n3 = n1 + n2;
	int i, j;
	int stride = 2048 / n;
	
	if (n == 1) return;
	else if (n == 2)
	{
		for (i = 0; i < s; i++)
		{
			double ar = RE(x, i),
			ai = IM(x, i),
			br = RE(x, i + s),
			bi = IM(x, i + s);
			RE(x, i) = ar + br;
			IM(x, i) = ai + bi;
			RE(x, i + s) = ar - br;
			IM(x, i + s) = ai - bi;
		}
	}
	else if (n > 2)
	{
		int theta = 0;
		int off = n1 * s;
		for (i = 0; i < n1; i++)
		{
			double w1r = get_cos(theta),
			w1i = get_sin(theta),
			w2r = w1r * w1r - w1i * w1i;
			w2i = 2 * w1r * w1i,
			w3r = w1r * w2r - w1i * w2i,
			w3i = w1r * w2i + w1i * w2r;
			for (j = 0; j < s; j++)
			{
				int tp = q + s * (p + n0);
				double ar = RE(x, tp),
				ai = IM(x, tp);
				tp += off;
				double br = RE(x, tp),
				bi = IM(x, tp);
				tp += off;
				double cr = RE(x, tp),
				ci = IM(x, tp);
				tp += off;
				double dr = RE(x, tp),
				di = IM(x, tp);
				
				double apcr = ar + cr,
				apci = ai + ci,
				amcr = ar - cr,
				amci = ai - ci,
				bpdr = br + dr,
				bpdi = bi + di,
				jbmdr = di - bi,
				jbmdi = br - dr;

				RE()
			}

 
			theta += stride;
		}
	}
}*/
