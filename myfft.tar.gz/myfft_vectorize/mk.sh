sw5cc -O2 -host -c main.c myfft_host.c -o main.o -I. -msimd
sw5cc -O2 -slave -c myfft_slave.c -o myfft_slave.o -msimd
#mpicxx -hybrid main.o myfft_host.o myfft_slave.o myfft_transpose.o -o myfft -msimd -lm -lm_slave -lswperf libfftw3.a libfftw3_threads.a libgsl.a libgslcblas.a 
mpicxx -hybrid main.o myfft_host.o myfft_slave.o -o myfft -msimd -lm -lm_slave libfftw3.a libfftw3_threads.a libgsl.a libgslcblas.a 
sshpass -p 123456 scp myfft root@192.167.253.104:/root/hzd
