#include "athread.h"
#include "simd.h"
#include "myfft.h"
#include <math.h>
#include <stdio.h>

#define SIX_STEP 1

inline unsigned long use_for_time()
{
        struct timeval val;
        gettimeofday(&val,NULL);
        return (val.tv_sec*1000000 + val.tv_usec);
}

extern SLAVE_FUN(myfft_slave)();
extern SLAVE_FUN(myfft_transpose)();

unsigned long t3, t4;

void transpose_square(int n, double *in)
{
	int i, j;
	int N = n * n;
	for (i = 0; i < n; i++)
		for (j = i + 1; j < n; j++)
		{
			double t = R(in, j + n * i);
			R(in, j + n * i) = R(in, i + n * j);
			R(in, i + n * j) = t;
			t = I(in, j + n * i, N);
			I(in, j + n * i, N) = I(in, i + n * j, N);
			I(in, i + n * j, N) = t;
		}
}

void transpose_multi(int n, double *in)
{
	int N = n * n;
	int i, j;
	int stride = 2048 / n;
	int st2 = stride * stride;
	for (i = 0; i < n; i++)
	{
		double theta0 = 2 * i * M_PI / N;
		double theta = i * theta0;
		for (j = i; j < n; j++)
		{
			double w_re = cos(theta),
			w_im = -sin(theta);
			if (i == j)
			{
				double ar = R(in, i + n * i),
				ai = I(in, i + n * i, N);
				R(in, i + n * i) = w_re * ar - w_im * ai;
				I(in, i + n * i, N) = w_re * ai + w_im * ar;
			}
			else
			{
				double ar = R(in, j + n * i),
				ai = I(in, j + n * i, N),
				br = R(in, i + n * j),
				bi = I(in, i + n * j, N);
				
				R(in, j + n * i) = w_re * br - w_im * bi;
				I(in, j + n * i, N) = w_re * bi + w_im * br;
				R(in, i + n * j) = w_re * ar - w_im * ai;
				I(in, i + n * j, N) = w_re * ai + w_im * ar;
			}
			theta += theta0;
		}
	}
}

void sixstep_fft(int log_N, double *in, double *out)
{
	const int N = 1 << log_N;
	const int n = 1 << (log_N / 2);
	int m = 0;
	
	double* args_t1[4] = {in, out, (double*)&n, (double*)&m};
	//transpose
	athread_spawn(myfft_transpose, args_t1);
	athread_join();
	//transpose_square(n, in);

	//FFT-1
	int start;
	int stride = 64 * n * 2;
	int d = 2;
	//gaile 
	double* args[4] = {out, in, (double*)&n, (double*)&d};	
	//double* args[4] = {in, out, (double*)&n, (double*)&d};	
	t3 = use_for_time();
	athread_spawn(myfft_slave, args);
	athread_join();
	t4 = use_for_time();
	//printf("haha\n");

	//transpose and multiply twiddle factor
	m = 1;
	athread_spawn(myfft_transpose, args_t1);
	athread_join();
	//transpose_multi(n, out);
	//transpose_square(n, in);
	//printf("haha\n");

	//FFT-2
	/*for (start = 0; start < 2 * N; start += stride)
	{
		double* args1[4] = {out + start, out + start, (double*)&n, (double*)&d};	
		athread_spawn(myfft_slave, args1);
		athread_join();
	}*/
	args[0] = out;
	args[1] = in;
	//args[1] = out;
	athread_spawn(myfft_slave, args);
	athread_join();
	
	//printf("haha\n");
	m = 0;
	athread_spawn(myfft_transpose, args_t1);
	athread_join();
	//transpose_square(n, out);
	//printf("haha\n");
}

void eightstep_fft(int log_N, double *in, double *out)
{
	int N = 1 << log_N;
	int m = N / 2;
	double theta0 = 2 * M_PI / N;
	int i;
	for (i = 0; i < m; i++)
	{
		double theta = i * theta0,
		wr = cos(theta),
		wi = -sin(theta),
		ar = RE(in, i),
		ai = IM(in, i),
		br = RE(in, i + m),
		bi = IM(in, i + m);
		RE(out, i) = ar + br;
		IM(out, i) = ai + bi;
		double tr = ar - br,
		ti = ai - bi;
		RE(out, i + m) = tr * wr - ti * wi;
		IM(out, i + m) = tr * wi + ti * wr;
	}
	sixstep_fft(log_N - 1, out, in);
	sixstep_fft(log_N - 1, out + 2 * m, in + 2 * m);
	for (i = 0; i < m; i++)
	{
		RE(out, 2 * i) = RE(in, i);
		IM(out, 2 * i) = IM(in, i);
		RE(out, 2 * i + 1) = RE(in, i + m);
		IM(out, 2 * i + 1) = IM(in, i + m);
	}
}

int myfft_hzd(double *in, double *out, int N, int direction)
{

	if (N % 2 != 0)
	{
		printf("Invalid intput array size!\n");
		return -1;
	}

	int i;
	//double* args[3] = {in, out, (double*)&N};
	
	unsigned long t1, t2;

	athread_init();
	t1 = use_for_time();
	
	int log_N = 0;
	for (i = N; i > 1; i >>= 1) log_N++;

	int j, n = 1 << (log_N / 2);
	/*for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
			printf("%.2f+%.2fi ",RE(in,j*n+i), IM(in,j*n+i));
		printf("\n");
	}*/

	if (SIX_STEP == 1)
	{
		if (!(log_N & 1)) sixstep_fft(log_N, in, out);
		else eightstep_fft(log_N, in, out);
	}
	else
	//transpose
	/*int m = 0;
	double* args_t1[4] = {in, out, (double*)&n, (double*)&m};
	athread_spawn(myfft_transpose, args_t1);
	athread_join();*/
	{
		int d = 1;
		double* args[4] = {in, out, (double*)&N, (double*)&d};
		athread_spawn(myfft_slave, args);
		athread_join();
	}
	
	/*for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
			printf("%.2f+%.2fi ",RE(out,i*n+j), IM(out,i*n+j));
		printf("\n");
	}*/
	//athread_spawn(myfft_slave, args);
	//athread_join();
	t2 = use_for_time();

	printf("Time: %f Calculation: %f\n", (t2 - t1) / US, (t4 - t3) / US);
}
